
import { NextRequest, NextResponse } from 'next/server';
import * as xlsx from 'xlsx';
import { writeFile } from 'fs/promises';
import { join } from 'path';

export async function POST(request: NextRequest) {
  try {
    const data = await request.formData();
    const file: File | null = data.get('file') as unknown as File;

    if (!file) {
      return NextResponse.json({ success: false, message: 'Nenhum arquivo enviado' });
    }

    // Validar tipo de arquivo
    if (!file?.name?.endsWith('.xlsx')) {
      return NextResponse.json({ success: false, message: 'Por favor, envie apenas arquivos .xlsx' });
    }

    // Converter file para buffer
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    // Salvar arquivo temporariamente
    const filename = `${Date.now()}-${file?.name || 'file.xlsx'}`;
    const filepath = join(process.cwd(), 'uploads', filename);
    
    await writeFile(filepath, buffer);

    // Processar planilha Excel
    try {
      // Ler diretamente do buffer ao invés do arquivo salvo
      const workbook = xlsx.read(buffer, { type: 'buffer' });
      
      // Procurar pela planilha "Cards"
      const cardsSheetName = workbook?.SheetNames?.find(name => 
        name.toLowerCase() === 'cards' || name === 'Cards'
      );
      
      if (!cardsSheetName) {
        return NextResponse.json({ 
          success: false, 
          message: 'Planilha "Cards" não encontrada. Verifique se existe uma aba chamada "Cards" no arquivo.' 
        });
      }
      
      const worksheet = workbook?.Sheets?.[cardsSheetName];
      
      if (!worksheet) {
        return NextResponse.json({ success: false, message: 'Não foi possível ler a planilha "Cards"' });
      }

      // Extrair valores das células A3 e D3 da planilha Cards
      const cellA3 = worksheet?.['A3']?.v || '';
      const cellD3 = worksheet?.['D3']?.v || '';

      return NextResponse.json({
        success: true,
        data: {
          cellA3: String(cellA3),
          cellD3: String(cellD3),
          combinedValue: `${cellA3} ${cellD3}`
        }
      });

    } catch (excelError) {
      console.error('Erro ao processar Excel:', excelError);
      return NextResponse.json({ success: false, message: 'Erro ao processar o arquivo Excel' });
    }

  } catch (error) {
    console.error('Erro no upload:', error);
    return NextResponse.json({ success: false, message: 'Erro interno do servidor' });
  }
}
