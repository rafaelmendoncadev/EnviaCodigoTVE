
'use client';

import { useState, useCallback } from 'react';
import { FileUploader } from './file-uploader';
import { ResultDisplay } from './result-display';
import { LoadingSpinner } from './loading-spinner';

interface ProcessedData {
  cellA3: string;
  cellD3: string;
  combinedValue: string;
}

export function FileProcessor() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<ProcessedData | null>(null);
  const [error, setError] = useState<string>('');

  const handleFileUpload = useCallback(async (file: File) => {
    setIsProcessing(true);
    setError('');
    setResult(null);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (data?.success) {
        setResult(data?.data || null);
      } else {
        setError(data?.message || 'Erro ao processar arquivo');
      }
    } catch (err) {
      console.error('Erro no upload:', err);
      setError('Erro ao enviar arquivo. Tente novamente.');
    } finally {
      setIsProcessing(false);
    }
  }, []);

  const handleReset = useCallback(() => {
    setResult(null);
    setError('');
    setIsProcessing(false);
  }, []);

  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl p-8">
      {isProcessing && (
        <div className="text-center py-12">
          <LoadingSpinner />
          <p className="mt-4 text-gray-600">Processando arquivo...</p>
        </div>
      )}

      {!isProcessing && !result && (
        <FileUploader onFileUpload={handleFileUpload} error={error} />
      )}

      {!isProcessing && result && (
        <ResultDisplay data={result} onReset={handleReset} />
      )}
    </div>
  );
}
