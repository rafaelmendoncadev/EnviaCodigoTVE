
'use client';

import { useState } from 'react';
import { Copy, Mail, MessageCircle, RefreshCw, Check, FileSpreadsheet } from 'lucide-react';

interface ResultDisplayProps {
  data: {
    cellA3: string;
    cellD3: string;
    combinedValue: string;
  };
  onReset: () => void;
}

export function ResultDisplay({ data, onReset }: ResultDisplayProps) {
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);

  const handleCopy = async () => {
    try {
      setCopyError(false);
      const textToCopy = data?.combinedValue || '';
      
      // Tentar usar a API moderna do Clipboard primeiro
      if (navigator?.clipboard && window?.isSecureContext) {
        await navigator.clipboard.writeText(textToCopy);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
        return;
      }
      
      // Fallback para método tradicional
      const textArea = document.createElement('textarea');
      textArea.value = textToCopy;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      textArea.style.top = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      
      const successful = document.execCommand('copy');
      document.body.removeChild(textArea);
      
      if (successful) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } else {
        throw new Error('Comando de cópia falhou');
      }
      
    } catch (err) {
      console.error('Erro ao copiar:', err);
      setCopyError(true);
      setTimeout(() => setCopyError(false), 3000);
    }
  };

  const handleEmail = () => {
    const subject = encodeURIComponent('Dados extraídos da planilha');
    const body = encodeURIComponent(`Dados processados: ${data?.combinedValue || ''}`);
    window?.open(`mailto:?subject=${subject}&body=${body}`);
  };

  const handleWhatsApp = () => {
    const message = encodeURIComponent(`Dados da planilha: ${data?.combinedValue || ''}`);
    window?.open(`https://wa.me/?text=${message}`);
  };

  return (
    <div className="text-center">
      {/* Success Header */}
      <div className="mb-8">
        <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <FileSpreadsheet className="w-8 h-8 text-green-600" />
        </div>
        <h3 className="text-2xl font-bold text-gray-800 mb-2">
          Arquivo processado com sucesso!
        </h3>
        <p className="text-gray-600">
          Os dados foram extraídos das células A3 e D3 da planilha "Cards"
        </p>
      </div>

      {/* Data Display */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 mb-8">
        <div className="grid md:grid-cols-3 gap-6">
          {/* Cell A3 */}
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <label className="text-sm font-medium text-gray-500 block mb-2">
              Célula A3
            </label>
            <div className="text-lg font-semibold text-gray-800 bg-gray-50 rounded p-2">
              {data?.cellA3 || '-'}
            </div>
          </div>

          {/* Cell D3 */}
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <label className="text-sm font-medium text-gray-500 block mb-2">
              Célula D3
            </label>
            <div className="text-lg font-semibold text-gray-800 bg-gray-50 rounded p-2">
              {data?.cellD3 || '-'}
            </div>
          </div>

          {/* Combined Value */}
          <div className="bg-white rounded-lg p-4 shadow-sm border-2 border-blue-200">
            <label className="text-sm font-medium text-blue-600 block mb-2">
              Valor Combinado
            </label>
            <div className="text-lg font-bold text-blue-800 bg-blue-50 rounded p-2">
              {data?.combinedValue || '-'}
            </div>
          </div>
        </div>
        
        {/* Campo de texto selecionável para cópia manual */}
        <div className="mt-6 bg-white rounded-lg p-4 shadow-sm border-2 border-dashed border-blue-300">
          <label className="text-sm font-medium text-blue-600 block mb-2">
            💡 Valor para cópia manual (caso necessário):
          </label>
          <input
            type="text"
            value={data?.combinedValue || ''}
            readOnly
            className="w-full text-lg font-bold text-blue-800 bg-blue-50 rounded p-3 border border-blue-200 focus:outline-none focus:ring-2 focus:ring-blue-400 select-all"
            onClick={(e) => (e.target as HTMLInputElement).select()}
          />
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap justify-center gap-4 mb-8">
        <button
          onClick={handleCopy}
          className={`
            flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all shadow-lg
            ${copied 
              ? 'bg-green-600 text-white' 
              : copyError
              ? 'bg-red-600 text-white'
              : 'bg-gradient-to-r from-blue-600 to-blue-700 text-white hover:from-blue-700 hover:to-blue-800 hover:shadow-xl'
            }
          `}
        >
          {copied ? (
            <>
              <Check className="w-5 h-5" />
              Copiado!
            </>
          ) : copyError ? (
            <>
              <Copy className="w-5 h-5" />
              Erro - Use campo abaixo
            </>
          ) : (
            <>
              <Copy className="w-5 h-5" />
              Copiar Valor
            </>
          )}
        </button>

        <button
          onClick={handleEmail}
          className="flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all shadow-lg
                   bg-gradient-to-r from-green-600 to-green-700 text-white 
                   hover:from-green-700 hover:to-green-800 hover:shadow-xl"
        >
          <Mail className="w-5 h-5" />
          Enviar Email
        </button>

        <button
          onClick={handleWhatsApp}
          className="flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all shadow-lg
                   bg-gradient-to-r from-green-500 to-green-600 text-white 
                   hover:from-green-600 hover:to-green-700 hover:shadow-xl"
        >
          <MessageCircle className="w-5 h-5" />
          WhatsApp
        </button>
      </div>

      {/* Reset Button */}
      <button
        onClick={onReset}
        className="flex items-center gap-2 mx-auto px-6 py-3 rounded-lg font-medium transition-all
                 text-gray-600 hover:text-gray-800 hover:bg-gray-100 border border-gray-300
                 hover:border-gray-400"
      >
        <RefreshCw className="w-5 h-5" />
        Processar Outro Arquivo
      </button>
    </div>
  );
}
