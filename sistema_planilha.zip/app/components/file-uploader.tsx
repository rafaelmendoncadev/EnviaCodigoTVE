
'use client';

import { useState, useRef, useCallback } from 'react';
import { Upload, FileSpreadsheet, AlertCircle } from 'lucide-react';

interface FileUploaderProps {
  onFileUpload: (file: File) => void;
  error: string;
}

export function FileUploader({ onFileUpload, error }: FileUploaderProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = e.dataTransfer?.files;
    if (files && files?.length > 0) {
      const file = files[0];
      if (file?.name?.endsWith('.xlsx')) {
        onFileUpload(file);
      }
    }
  }, [onFileUpload]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target?.files;
    if (files && files?.length > 0) {
      const file = files[0];
      if (file?.name?.endsWith('.xlsx')) {
        onFileUpload(file);
      }
    }
  }, [onFileUpload]);

  const handleClick = useCallback(() => {
    fileInputRef?.current?.click();
  }, []);

  return (
    <div className="text-center">
      <div
        className={`
          border-2 border-dashed rounded-xl p-12 transition-all cursor-pointer
          ${isDragOver 
            ? 'border-blue-500 bg-blue-50' 
            : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50/50'
          }
        `}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={handleClick}
      >
        <div className="flex flex-col items-center space-y-4">
          <div className="bg-gradient-to-br from-blue-500 to-purple-600 p-4 rounded-full">
            <Upload className="w-8 h-8 text-white" />
          </div>
          
          <div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              Selecione ou arraste seu arquivo Excel
            </h3>
            <p className="text-gray-500">
              Apenas arquivos .xlsx são aceitos
            </p>
          </div>

          <button
            type="button"
            onClick={handleClick}
            className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-lg 
                     hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg hover:shadow-xl
                     flex items-center gap-2 font-medium"
          >
            <FileSpreadsheet className="w-5 h-5" />
            Escolher Arquivo
          </button>
        </div>
      </div>

      {error && (
        <div className="mt-4 p-4 bg-red-50 border-l-4 border-red-500 rounded-lg">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
            <p className="text-red-700 font-medium">{error}</p>
          </div>
        </div>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept=".xlsx"
        onChange={handleFileSelect}
        className="hidden"
      />
    </div>
  );
}
